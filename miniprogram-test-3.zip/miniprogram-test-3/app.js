//app.js
App({
  onLaunch: function () {


  },
  globalData: {
    url: 'https://ds.largehill.net',  // 数据请求前缀
    imgUrl: '',      // 图片请求前缀
    uid: null,
    openid: '',
    openPages: '',
    spid: 0,
  },
  setBarColor: function () {
    var that = this;

    wx.setNavigationBarColor({
      frontColor: '#000000',
      backgroundColor: '#red',
    })
  },
  setUserInfo: function () {
    var that = this;
    if (that.globalData.uid == null) {//是否存在用户信息，如果不存在跳转到首页
      wx.showToast({
        title: '需要先登录',
        icon: 'none',
        duration: 1500,
      })
      setTimeout(function () {
        wx.reLaunch({
          url: '/pages/user/index',
        })
      }, 1500)
    }
  },
})