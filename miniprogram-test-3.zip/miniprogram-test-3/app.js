//app.js
App({
  onLaunch: function () {


  },
  globalData: {
    url: 'https://ds.largehill.net',  // 数据请求前缀
    imgUrl: 'https://www.largehill.com/dashan/public',      // 图片请求前缀
    uid: null,
    openid: '',
    openPages: '',
    spid: 0,
  },
  setBarColor: function () {
    var that = this;

    wx.setNavigationBarColor({
      frontColor: '#000000',
      backgroundColor: '#red',
    })
  },
  setUserInfo: function () {
    var that = this;
    if (that.globalData.uid == null) {//是否存在用户信息，如果不存在跳转到首页
      wx.showToast({
        title: '用户信息获取失败',
        icon: 'none',
        duration: 1500,
      })
      setTimeout(function () {
        wx.navigateTo({
          url: '/pages/load/load',
        })
      }, 1500)
    }
  },
})