// pages/index/index.js
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    TabCur: 0,
    scrollLeft: 0,
    TabTitles: [],
    TabDatas: [],
    offset: 1,
    limit: 8,
    hidden: false,
    tabSelectId: 0
  },
  /**
*  每次加载文章
*/
  onShowTabSelect(classificationid,len) {
    var that = this;

    wx.request({
      url: app.globalData.url + '/routine/auth_api/get_cid_article?uid=' + app.globalData.uid + '&xiaoben=true',
      method: 'GET',
      data: {
        cid: classificationid,
        first: 0,
        limit: len
      },
      success: function (res) {
        if (res.data.code == 200) {
          for (var i = 0; i < res.data.data.length; i++) {
            var image_inputs = res.data.data[i].image_inputs.split(',');
            if (image_inputs.length > 1) {
              image_inputs.splice(image_inputs.length - 1, 1);
              res.data.data[i].image_inputs = image_inputs;
            }
          };

          that.setData({
            TabDatas: res.data.data
          });

        } else {
          wx.showToast({
            title: "根据id获取广告列表失败",
            icon: 'none',
            duration: 2000
          });
        };
      }
    });
  },
  /**
   * 文章title
   */
  tabSelect(e) {
    var that = this;
    that.setData({
      TabCur: e.currentTarget.dataset.id,
      scrollLeft: (e.currentTarget.dataset.id - 1) * 60
    });

    var classificationId = e.currentTarget.dataset.classificationid;

    if (that.data.tabSelectId != classificationId) {
      that.data.offset = 1;
    };
    that.data.tabSelectId = classificationId;
    wx.request({
      url: app.globalData.url + '/routine/auth_api/get_cid_article?uid=' + app.globalData.uid + '&xiaoben=true',
      method: 'GET',
      data: {
        cid: classificationId,
        first: 0,
        limit: 8
      },
      success: function (res) {
        if (res.data.code == 200) {
          that.setData({
            TabDatas: res.data.data
          });
        } else {
          wx.showToast({
            title: "根据id获取资讯列表失败",
            icon: 'none',
            duration: 2000
          });
        };
      }
    });
  },
  getTabTitle: function () {
    var header = {
      'content-type': 'application/x-www-form-urlencoded',
    };
    var that = this;
    wx.request({
      url: app.globalData.url + '/routine/auth_api/getpid?uid=' + app.globalData.uid + '&xiaoben=true',
      method: 'GET',
      header: header,
      success: function (res) {
        if (res.data.code == 200) {
          var data = res.data.data;
              that.data.TabTitles = [];
          for (var i = 0; i < data.length; i++) {
            if (data[i].title == '资讯互动') {
              var id = data[i].id;
              for (var j = 0; j < data.length; j++) {
                if (data[j].pid == id) {
                  that.data.TabTitles.push(data[j]);
                }
              };
              break;
            };
          };

          that.tabSelect({ currentTarget: { dataset: { id: 0, classificationid: that.data.TabTitles[0].id } } });
          that.setData({
            TabTitles: that.data.TabTitles
          });

        } else {
          wx.showToast({
            title: "获取资讯分类失败",
            icon: 'none',
            duration: 2000
          });
        };
      }
    });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
   // app.setUserInfo();
   // if (!app.globalData.uid) return;
   // var that = this;
   // that.getTabTitle();   // 资讯互动文章数据请求
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;

        if (that.data.TabTitles.length > 0) {
          that.onShowTabSelect(that.data.tabSelectId, that.data.TabDatas.length);
        } else {
          that.getTabTitle();
        };
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    var that = this;
    var limit = 8;

    if (that.data.hidden) return;

    var offset = that.data.offset++ * limit;

    that.setData({
      hidden: true,
    });

    wx.request({
      url: app.globalData.url + '/routine/auth_api/get_cid_article?uid=' + app.globalData.uid + '&xiaoben=true',
      data: { cid: that.data.tabSelectId, limit: limit, first: offset },
      method: 'GET',
      success: function (res) {
        if (res.data.data.length < 1) {
          --that.data.offset;
          wx.showToast({
            title: '没有更多的资讯了',
            icon: 'none',
            duration: 2000
          })
        } else {
          that.data.TabDatas = that.data.TabDatas.concat(res.data.data);
        };
        that.setData({
          hidden: false,
          TabDatas: that.data.TabDatas
        });
      },
      fail: function (res) {
        console.log('submit fail');
      },
      complete: function (res) {
        console.log('submit complete');
      }
    })
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})