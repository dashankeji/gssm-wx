// pages/businessSpecialShopping_more/index.js
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    all: [],
    offset: 1,
    hidden: false
  },
  getIndexInfo: function () {

    var header = {
      'content-type': 'application/x-www-form-urlencoded',
    };
    var that = this;
    wx.request({
      url: app.globalData.url + '/routine/auth_api/index?uid=' + app.globalData.uid + '&xiaoben=true',
      method: 'GET',
      data: {
        offset: 0,
        limit: 8
      },
      header: header,
      success: function (res) {

        that.setData({
          all: res.data.data.all
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
    var that = this;
        that.getIndexInfo();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    var that = this;
    var limit = 8;

    if (that.data.hidden) return;

    var offset = that.data.offset++ * limit;

    that.setData({
      hidden: true,
    });

    var header = {
      'content-type': 'application/x-www-form-urlencoded',
    };
    wx.request({
      url: app.globalData.url + '/routine/auth_api/index?uid=' + app.globalData.uid + '&offset=' + offset + '&limit=' + limit + '&xiaoben=true',
      method: 'GET',
      header: header,
      success: function (res) {
        if (res.data.data.all.length < 1) {
          --that.data.offset;
          wx.showToast({
            title: '没有更多的商品了',
            icon: 'none',
            duration: 2000
          })
        } else {
          that.data.all = that.data.all.concat(res.data.data.all);
        };
        that.setData({
          hidden: false,
          all: that.data.all
        })
      }
    });
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})