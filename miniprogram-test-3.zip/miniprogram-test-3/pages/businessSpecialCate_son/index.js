// pages/businessSpecialCate_son/index.js
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    cateData: [],
    cateShoppingData: [],
    GbCateId: 0,
    GbCateIdTwo: 0,
    GbCateName: '',
    hidden: true,
    offset: 1,
    GbShopId: -1
  },
  ClassificationListReq: function (title) {
    var header = {
      'content-type': 'application/x-www-form-urlencoded',
    };
    var that = this;
    wx.request({
      url: app.globalData.url + '/routine/auth_api/get_product_category?uid=' + app.globalData.uid + '&xiaoben=true',
      method: 'POST',
      header: header,
      success: function (res) {
        that.setData({
          hidden: false
        });
        for (var i = 0; i < res.data.data.length; i++) {
          if (res.data.data[i].cate_name == title && res.data.data[i].child.length > 0) {
            
            that.data.cateData.push({ pic: "../../images/2-2.png", cate_name: "全部", id: -2 });
            var child = res.data.data[i].child;
            that.setData({
              cateData: that.data.cateData.concat(child),
            });
            that.getCateShoppingData(null,that.data.cateData[0].id,"全部");
            break;
          }
        };

      }
    });
  },
  getCateShoppingData: function (e, id, cate_name) {
    var that = this;
    var cateId = e ? e.currentTarget.dataset.id : id;

    if (that.data.GbCateId == cateId) {
      return;
    } else {
      that.data.offset = 1;
    };
    
   
    
    var pidId = that.data.GbShopId;
    var sonId = cateId;

    if (sonId == -2) { sonId = 0;  }
    else { console.log(e.currentTarget.dataset.catename); that.setData({ GbCateIdTwo: cateId, GbCateName: e.currentTarget.dataset.catename });   };

    var header = {
      'content-type': 'application/x-www-form-urlencoded',
    };
    wx.request({
      url: app.globalData.url + '/routine/auth_api/get_product_list?uid=' + app.globalData.uid + '&xiaoben=true',
      method: 'GET',
      data: { sid: sonId, cid: pidId, priceOrder: '', salesOrder: '', news: '', first: 0, limit: 8 },
      header: header,
      success: function (res) {

       that.setData({
          cateShoppingData: res.data.data,
          hidden: false
        });
  
      }
    });
    that.setData({
      hidden: true,
      GbCateId: cateId
    });

  },
  wrapMenuSelect: function(e) {
    var that = this;
    
        that.getCateShoppingData(e);
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    if(!options.title) options.title = '暂无标题';
    var that = this;
        that.data.GbShopId = options.id;
        wx.setNavigationBarTitle({
          title: options.title,
        });
        that.ClassificationListReq(options.title);
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    var that = this;
    var limit = 8;

    if (that.data.hidden) return;

    var offset = that.data.offset++ * limit;

    that.setData({
      hidden: true,
    });

    var pidId = that.data.GbShopId;
    var cateId = that.data.GbCateId;
    if (cateId == -2) { cateId = 0;  };

    var header = {
      'content-type': 'application/x-www-form-urlencoded',
    };
    wx.request({
      url: app.globalData.url + '/routine/auth_api/get_product_list?uid=' + app.globalData.uid,
      method: 'GET',
      data: { sid: cateId, cid: pidId, priceOrder: '', salesOrder: '', news: '', first: offset, limit: 8 },
      header: header,
      success: function (res) {
        if (res.data.data.length < 1) {
          --that.data.offset;
          wx.showToast({
            title: '没有更多的商品了',
            icon: 'none',
            duration: 2000
          })
        } else {
          that.data.cateShoppingData = that.data.cateShoppingData.concat(res.data.data);
        };
        that.setData({
          hidden: false,
          cateShoppingData: that.data.cateShoppingData
        })
      }
    });
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})